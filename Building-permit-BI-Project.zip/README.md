# Building-permit-BI-Project


This project was part of a school project at ISEP. The objective is to analyze a dataset containing the various building permits issued in San Fransico and make predictions on it. 


